from kivy.uix.screenmanager import Screen


class KitchenSinkCards(Screen):
    pass
